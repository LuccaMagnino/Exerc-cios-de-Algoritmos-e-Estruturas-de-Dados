#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"

Pilha* criar_pilha() {
    Pilha *p = (Pilha*) malloc(sizeof(Pilha));
    inicializar_pilha(p);
    return p;
}

void inicializar_pilha(Pilha *p) {
    p->topo = -1;
}

void liberar_pilha(Pilha *p) {
    free(p);
}

int tamanho_pilha(Pilha *p) {
    return p->topo + 1;
}

int pilha_vazia(Pilha *p) {
    return (p->topo == -1);
}

int pilha_cheia(Pilha *p) {
    return (p->topo == MAX - 1);
}

int push(Pilha *p, int valor) {
    if (pilha_cheia(p)) {
        return 0; 
    }
    p->elementos[++(p->topo)] = valor;
    return 1;
}

int pop(Pilha *p, int *valor) {
    if (pilha_vazia(p)) {
        return 0;
    }
    *valor = p->elementos[(p->topo)--];
    return 1; 
}
int consulta_topo(Pilha *p, int *valor) {
    if (pilha_vazia(p)) {
        return 0; 
    }
    *valor = p->elementos[p->topo];
    return 1; 
}

void imprimir_pilha(Pilha *p) {
    if (pilha_vazia(p)) {
        printf("Vazio\n");
    } else {
        printf("Pilha: ");
        for (int i = p->topo; i >= 0; i--) {
            printf("%d ", p->elementos[i]);
        }
        printf("\n");
    }
}
