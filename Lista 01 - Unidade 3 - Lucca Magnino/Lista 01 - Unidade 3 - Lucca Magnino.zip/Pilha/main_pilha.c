#include <stdio.h>
#include "pilha.h"

int main() {
    Pilha *p = criar_pilha();

    push(p, 10);
    push(p, 20);
    push(p, 30);
    
    imprimir_pilha(p); 

    int topo;
    if (consulta_topo(p, &topo)) {
        printf("Elemento no topo: %d\n", topo);
    }

    int removido;
    if (pop(p, &removido)) {
        printf("Elemento removido: %d\n", removido);
    }

    imprimir_pilha(p); 

    printf("Tamanho da pilha: %d\n", tamanho_pilha(p));

    liberar_pilha(p);

    return 0;
}
