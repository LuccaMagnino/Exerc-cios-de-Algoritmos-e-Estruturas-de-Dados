#define MAX 100

typedef struct {
    int topo;
    int elementos[MAX];
} Pilha;


Pilha* criar_pilha();
void inicializar_pilha(Pilha *p);
void liberar_pilha(Pilha *p);
int tamanho_pilha(Pilha *p);
int pilha_vazia(Pilha *p);
int pilha_cheia(Pilha *p);
int push(Pilha *p, int valor);
int pop(Pilha *p, int *valor);
int consulta_topo(Pilha *p, int *valor);
void imprimir_pilha(Pilha *p);


